# 🌞 3D Solar System – Frontend Developer Assignment

This project is a **3D solar system simulation** using **Three.js** and **pure JavaScript**.  
It runs in the browser and shows 8 planets orbiting around the Sun, with controls to adjust their speed.

---

## 🔧 How to Run the Project (Step-by-Step)

1. **Download or unzip** the folder
2. Make sure these 3 files are present:
   - `index.html`
   - `style.css`
   - `script.js`
3. Just **double-click on `index.html`** or open it using Chrome/Edge/Firefox
4. The 3D simulation will start running automatically
5. Use the sliders to **change speed** of each planet
6. Click the "Pause" button to **stop/resume animation**

✅ No server or software installation is needed

---

## 🎯 Features Implemented

- Sun at the center
- 8 planets orbiting the sun (Mercury to Neptune)
- Different orbit speeds for each planet
- **Real-time speed control sliders**
- **Pause/Resume** animation button
- **Stars background** for realism
- Fully mobile-responsive
- Built using only **Three.js + JavaScript** (no CSS animation)

---

## 📹 Demo Video Guide (What to Show)

🎥 Make a short video (2–3 min) showing:

1. The solar system running (planets orbiting)
2. Speed sliders working in real-time
3. Pause and resume button working
4. Quick explanation:
   - How planets are created (with spheres)
   - How orbit animation works
   - Folder & file walkthrough

---

## 🗂 Folder Structure

