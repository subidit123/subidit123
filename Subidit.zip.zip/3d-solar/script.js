const canvas = document.getElementById("solarCanvas");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

// Camera Setup
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 20, 70);
camera.lookAt(scene.position);

// Renderer Setup
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);

// Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
scene.add(ambientLight);

const pointLight = new THREE.PointLight(0xffffff, 3);
pointLight.position.set(0, 0, 0);
scene.add(pointLight);

// Sun
const sun = new THREE.Mesh(
  new THREE.SphereGeometry(3.5, 64, 64),
  new THREE.MeshBasicMaterial({ color: 0xffff33 })
);
scene.add(sun);

// Stars Background
const starGeo = new THREE.BufferGeometry();
const starCount = 1000;
const starPositions = [];
for (let i = 0; i < starCount; i++) {
  const x = (Math.random() - 0.5) * 1000;
  const y = (Math.random() - 0.5) * 1000;
  const z = (Math.random() - 0.5) * 1000;
  starPositions.push(x, y, z);
}
starGeo.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.8 });
scene.add(new THREE.Points(starGeo, starMat));

// Planet Data
const planetData = [
  { name: 'Mercury', size: 0.6, dist: 10, speed: 0.04, color: 0xaaaaaa },
  { name: 'Venus',   size: 0.9, dist: 14, speed: 0.035, color: 0xffcc99 },
  { name: 'Earth',   size: 1.0, dist: 18, speed: 0.03, color: 0x3399ff },
  { name: 'Mars',    size: 0.8, dist: 22, speed: 0.025, color: 0xff3300 },
  { name: 'Jupiter', size: 2.2, dist: 28, speed: 0.02, color: 0xff9966 },
  { name: 'Saturn',  size: 2.0, dist: 34, speed: 0.015, color: 0xffffcc },
  { name: 'Uranus',  size: 1.5, dist: 40, speed: 0.012, color: 0x66ffff },
  { name: 'Neptune', size: 1.5, dist: 46, speed: 0.01, color: 0x6666ff }
];

const planets = [];
const angles = [];
const speeds = [];

// Create Planets
planetData.forEach((p, i) => {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(p.size, 32, 32),
    new THREE.MeshStandardMaterial({ color: p.color })
  );
  mesh.position.x = p.dist;
  scene.add(mesh);
  planets.push(mesh);
  angles.push(Math.random() * Math.PI * 2);
  speeds.push(p.speed);
  createSpeedSlider(i, p.name, p.speed);
});

// Create Speed Sliders
function createSpeedSlider(i, name, defaultSpeed) {
  const controls = document.getElementById("controls");
  const label = document.createElement("label");
  label.innerText = `${name}: `;
  const input = document.createElement("input");
  input.type = "range";
  input.min = "0.001";
  input.max = "0.05";
  input.step = "0.001";
  input.value = defaultSpeed;
  input.oninput = () => (speeds[i] = parseFloat(input.value));
  controls.appendChild(label);
  controls.appendChild(input);
  controls.appendChild(document.createElement("br"));
}

// Pause / Resume Animation
let isPaused = false;
document.getElementById("pauseBtn").onclick = () => {
  isPaused = !isPaused;
  document.getElementById("pauseBtn").innerText = isPaused ? "▶ Resume" : "⏸ Pause";
};

// Animate
function animate() {
  requestAnimationFrame(animate);

  if (!isPaused) {
    sun.rotation.y += 0.002;
    planets.forEach((planet, i) => {
      angles[i] += speeds[i];
      planet.position.x = Math.cos(angles[i]) * planetData[i].dist;
      planet.position.z = Math.sin(angles[i]) * planetData[i].dist;
      planet.rotation.y += 0.01;
    });
  }

  renderer.render(scene, camera);
}
animate();

// Handle Resize
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
